#include <jni.h>
#include <string.h>
#include <stdio.h>
#include <android/log.h>
#include <time.h>

#define DEBUG_TAG "NDK_AndroidNDK1SampleActivity"


void Java_learn2crack_customgridview_GuestbookActivity_helloLog(JNIEnv *env,jobject this,jstring logThis)
{
	jboolean isCopy;
	const char * szLogThis = (*env)->GetStringUTFChars(env, logThis, &isCopy);
	
	__android_log_print(ANDROID_LOG_DEBUG, DEBUG_TAG, "NDK:LC: [%s]", szLogThis);
	
	(*env)->ReleaseStringUTFChars(env, logThis, szLogThis);
}



jstring Java_learn2crack_customgridview_GuestbookActivity_getString(JNIEnv *env,jobject this,jint value1,jint value2)
{
	char *szFormat = "The sum of the two numbers is: %i";
	char *szResult;
	char *temp;




    struct timespec res;
    struct timeval val;
    double data;
    char str[15];
    clock_gettime(CLOCK_REALTIME, &res);
    //temp=malloc(sizeof(szFormat)+100);
    //getTimeStamp();
    //temp=getTimeStamp();
    //gettimeofday(&val,0);

    //sprintf(str, "%lf", 1000.0*res.tv_sec + (double)res.tv_nsec/1e6);

//
//	// add the two values
	//jlong sum = value1+value2;
//
//	// malloc room for the resulting string
	szResult = malloc(sizeof(szFormat) + 100);
//
//	// standard sprintf
	//sprintf(szResult, "%lf", 1000.0*res.tv_sec + (double)res.tv_nsec/1e6);
	//sprintf(szResult,"%lf",1000.0)
	//sprintf(szResult,"%lf",res.tv_sec+(double)res.tv_nsec/1e9)
	//sprintf(szResult,"%Lf",res.tv_sec+(long double)res.tv_nsec/1e9);
	sprintf(szResult,"%u.%09u",res.tv_sec,res.tv_nsec);
	//sprintf(szResult,"%d.%d",val.tv_sec,val.tv_usec);
//
//	// get an object string
	jstring result = (*env)->NewStringUTF(env, szResult);

	//jstring result=(* env)->NewStringUTF(env,temp);

//
//	// cleanup
	free(szResult);
	//free(temp);


	
    //struct timespec res;
    //double data;
    //char str[15];
    //clock_gettime(CLOCK_REALTIME, &res);

    //sprintf(str, "%lf", 1000.0*res.tv_sec + (double)res.tv_nsec/1e6);

	
	
	
	
	
	return result;
}



static double
now_ms(void)
{
    struct timespec res;
    clock_gettime(CLOCK_REALTIME, &res);
    return 1000.0*res.tv_sec + (double)res.tv_nsec/1e6;
}

