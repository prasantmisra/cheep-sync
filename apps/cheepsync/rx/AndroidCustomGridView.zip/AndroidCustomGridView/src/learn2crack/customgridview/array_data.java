package learn2crack.customgridview;

import android.bluetooth.BluetoothDevice;

public class array_data {
	
	BluetoothDeviceTemp device;
	String time;
	String android_nano_time;
	String push_android_time;
	double diff_time[];
	public double[] getDiff_time() {
		return diff_time;
	}
	public void setDiff_time(double[] diff_time) {
		this.diff_time = diff_time;
	}
	public BluetoothDeviceTemp getDevice() {
		return device;
	}
	public void setDevice(BluetoothDevice device_in) {
		this.device=new BluetoothDeviceTemp();
		device.setDevice_addr(device_in.getAddress());
		device.setName(device_in.getName());
		this.device = device;
	}
	
	public void setDeviceBluetooth(BluetoothDeviceTemp temp)
	{
		this.device=temp;
	}
	//Node time
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	public void setAndroid_Nano_Time(String time)
	{
		android_nano_time=time;
		
	}
	
	public String get_Android_Nano_Time()
	{
		return android_nano_time;
	}
	
	
	

}
