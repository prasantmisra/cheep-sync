package learn2crack.customgridview;

public class BluetoothDeviceTemp {

	String device_addr;
	String name;
	public String getAddress() {
		return device_addr;
	}
	public void setDevice_addr(String device_addr) {
		this.device_addr = device_addr;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
