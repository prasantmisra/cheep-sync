package learn2crack.customgridview;

import java.util.Calendar;

import android.util.Log;

public class Time_Node {
	
	String input_time;
	int hours;
	int minutes;
	long millis;
	int seconds;
	public String getInput_time() {
		return input_time;
	}
	public void setInput_time(String input_time) {
		this.input_time = input_time;
	}
	public int getHours() {
		return hours;
	}
	public void setHours(int hours) {
		this.hours = hours;
	}
	public int getMinutes() {
		return minutes;
	}
	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}
	public long getMillis() {
		return millis;
	}
	public void setMillis(long millis) {
		this.millis = millis;
	}
	public int getSeconds() {
		return seconds;
	}
	public void setSeconds(int seconds) {
		this.seconds = seconds;
	}
	
	
	
	public void calculate_offset()
	{
		//Find offset between current nodes time
		//and given time
		Calendar c = Calendar.getInstance(); 
		int seconds = c.get(Calendar.SECOND);
		int minutes=c.get(Calendar.MINUTE);
				int hours=c.get(Calendar.HOUR);
				//The input_time is in milli seconds
				//So we will calculate offset in miiliseconds
				long millis=c.get(Calendar.MILLISECOND);
				Log.d("milli",Long.toString(millis));
		
	}
	
	
	
	
	
	
	
	
	
	
	

}
