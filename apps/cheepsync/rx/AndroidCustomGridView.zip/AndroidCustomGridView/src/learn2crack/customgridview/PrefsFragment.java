package learn2crack.customgridview;
import android.os.Bundle;
import android.preference.PreferenceFragment;
import com.google.cloud.backend.R;

public class PrefsFragment extends PreferenceFragment {

 @Override
 public void onCreate(Bundle savedInstanceState) {
  // TODO Auto-generated method stub
  super.onCreate(savedInstanceState);
  
  // Load the preferences from an XML resource
        addPreferencesFromResource(R.xml.preferences);
 }

}