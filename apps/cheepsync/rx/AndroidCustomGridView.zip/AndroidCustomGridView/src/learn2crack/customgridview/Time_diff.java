package learn2crack.customgridview;

import java.util.Calendar;

import android.util.Log;

public class Time_diff {
	
	String input_time;
	public void setInputTime(String time)
	{
		this.input_time=time;
	}
	
	public void calculate_offset()
	{
		//Find offset between current nodes time
		//and given time
		Calendar c = Calendar.getInstance(); 
		int seconds = c.get(Calendar.SECOND);
		int minutes=c.get(Calendar.MINUTE);
				int hours=c.get(Calendar.HOUR);
				//The input_time is in milli seconds
				//So we will calculate offset in miiliseconds
				long millis=c.get(Calendar.MILLISECOND);
				Log.d("milli",Long.toString(millis));
		
	}

}
