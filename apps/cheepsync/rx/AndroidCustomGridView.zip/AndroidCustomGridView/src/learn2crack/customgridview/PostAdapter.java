package learn2crack.customgridview;


import com.google.cloud.backend.R;
import com.google.cloud.backend.core.CloudEntity;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.MathContext;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

/**
 * This ArrayAdapter uses CloudEntities as items and displays them as a post in
 * the guestbook. Layout uses row.xml.
 *
 */
public class PostAdapter extends ArrayAdapter<CloudEntity> {

    private static final SimpleDateFormat SDF = new SimpleDateFormat("HH:mm:ss ", Locale.US);

    private LayoutInflater mInflater;
    int size;

    /**
     * Creates a new instance of this adapter.
     *
     * @param context
     * @param textViewResourceId
     * @param objects
     */
    public PostAdapter(Context context, int textViewResourceId, List<CloudEntity> objects) {
        super(context, textViewResourceId, objects);
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        size=objects.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView != null ?
                convertView : mInflater.inflate(R.layout.row_post, parent, false);

        CloudEntity ce = getItem(position);
        if (ce != null) {
            TextView message = (TextView) view.findViewById(R.id.messageContent);
            TextView signature = (TextView) view.findViewById(R.id.signature);         
      		TextView time_offset=(TextView) view.findViewById(R.id.time_offset);
            if (message != null) {
                message.setText(ce.get("message").toString()+" "+ce.get("time")+" "+GuestbookActivity.name+" "+ce.get("mac_addr")+ce.get("name"));
            }
            if (signature != null) {
                signature.setText(ce.get("name")+" "+getAuthor(ce) + " " + SDF.format(ce.getCreatedAt()));
            }
            //Log.d("position",Integer.toString(position));
            //Log.d("size",Integer.toString(size));
            		if(!GuestbookActivity.master && position==0)
            		{
            			//We set the time_offset here
            			//We already have a cloud entity here which is the previous reference
            			//We can use that to compute the difference in time
            			//We have the latest scanned time
            			//Right now we dont want to compare with the cloud
            			//How do we find the current time on the node?
            			//SO lets assume that we use the latest measure on the incoming message
//            			int hours=Integer.parseInt(ce.get("android_hour").toString());
//            			int minutes=Integer.parseInt(ce.get("android_minute").toString());
//            					int seconds=Integer.parseInt(ce.get("android_second").toString());
//                         long millis=Long.parseLong(ce.get("android_millis").toString());
//                         long time_node=Long.parseLong(ce.get("time").toString());
//                         
//                         Time_Node time_complete=GuestbookActivity.getTime();
            			//Lets handle the exceptions here
            			
            			try
            			{
            				//This is the time at which data was inserted
            				String android_time=ce.get("nano_time").toString();
            				String node_time=ce.get("time").toString();
            				//We need to get current value of counter as well as timestamp
            				String current_android_time=GuestbookActivity.data_node.get(ce.get("mac_addr")).getAndroid_nano_time();
            				String current_node_time=GuestbookActivity.data_node.get(ce.get("mac_addr")).getNode_time();
            				//Now we find the actual time elapsed
            				//Always use doubles
            				double prev_android_nano_time=Double.parseDouble(android_time);
            				
            				double current_android_nano_time=Double.parseDouble(current_android_time);
            				//time elapsed
            				double elapsed=current_android_nano_time-prev_android_nano_time;
            				//elapsed=elapsed*Math.pow(10, 6);
            				double prev_node_time=Double.parseDouble(node_time);
            				double current_node_time_count=Double.parseDouble(current_node_time);
            				double node_elapsed=current_node_time_count-prev_node_time;
            				node_elapsed=node_elapsed*0.2037533/1000;
            				if(elapsed<0)
            				{
            					Log.d("data3","negative");
            					elapsed=elapsed*-1;
            				}
            				if(node_elapsed<0)
            				{
            					Log.d("data3","negative");
            					node_elapsed=node_elapsed*-1;
            				}
            				GuestbookActivity temp=new GuestbookActivity();
            				time_offset.setText("Node is "+node_elapsed+" phone is "+elapsed);
            				Log.d("data12",android_time+"a"+current_android_time);
            				Log.d("data12",node_time   +"a"+current_node_time);
            				Log.d("data1","node is "+Double.toString(node_elapsed)+" phone is "+Double.toString(elapsed));
            				double offset1=prev_android_nano_time-((prev_node_time)*0.200/1000)-1402800000;
            				double offset2=current_android_nano_time-((current_node_time_count)*0.200/1000)-1402800000;
            				Log.d("data3","Offset 1 is "+Double.toString(offset1)+" offset2 is "+Double.toString(offset2));
            				
            					if((node_elapsed-elapsed>0.1)|| (elapsed-node_elapsed)>0.1)
            					{
            						Log.d("data2"," Node is "+node_elapsed+" phone is "+elapsed);
            						Log.d("data2","Offset 1 is "+Double.toString(offset1)+" offset 2 "+Double.toString(offset2));
            						Log.d("sheep",""+node_elapsed+" "+elapsed+" "+Double.toString(offset1)+" "+Double.toString(offset2)+" "+node_time+" "+current_node_time+" "+android_time+" "+current_android_time+" "+temp.getNanoTime());
            						//Log.d("sheep","Offset 1 is "+Double.toString(offset1)+" offset 2 "+Double.toString(offset2));
            						//Log.d("sheep","count on phone 1 "+node_time+"count on phone 2 "+current_node_time);
            						//Log.d("sheep","time on phone 1 "+android_time+" time on phone 2 "+android_time);
            					}
            					else
            					{
            						Log.d("sheep",""+node_elapsed+" "+elapsed+" "+Double.toString(offset1)+" "+Double.toString(offset2)+" "+node_time+" "+current_node_time+" "+android_time+" "+current_android_time+" "+temp.getNanoTime());
            						//Log.d("sheep","Offset 1 is "+Double.toString(offset1)+" offset 2 "+Double.toString(offset2));
            						//Log.d("sheep","count on phone 1 "+node_time+"count on phone 2 "+current_node_time);
            						//Log.d("sheep","time on phone 1 "+android_time+" time on phone 2 "+android_time);
            					}
//            				BigDecimal prev_android_nano_time=new BigDecimal(android_time);
//            				BigDecimal current_android_nano_time=new BigDecimal(current_android_time);
//            				//MathContext mc=new MathContext(9);
//            				BigDecimal elapsed_time;
//            				elapsed_time=current_android_nano_time.subtract(prev_android_nano_time);
//            				BigDecimal prev_node_time=new BigDecimal(node_time);
//            				BigDecimal current_node_time_count=new BigDecimal(current_node_time);
//            				BigDecimal node_elapsed;
//            				node_elapsed=current_node_time_count.subtract(prev_node_time);
//            				node_elapsed=node_elapsed.multiply(new BigDecimal(Math.pow(10, -1)));
//            				time_offset.setText("Node is "+node_elapsed+" phone is "+elapsed_time);
            				
            				
            				
            			}
                         
            			catch(Exception e)
            			{
            				Log.d("Entry","entered");
            			}
                         
            			
            			
            			
            			
            		}
            		else
            		{
            			try
            			{
            			time_offset.setText(GuestbookActivity.data_node.get(ce.get("mac_addr")).getAndroid_nano_time());
            			}
            			
            			catch(Exception e)
            			{
            				
            			}
            			
            			}
            		
        }

        return view;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return this.getView(position, convertView, parent);
    }

    /**
     * Gets the author field of the CloudEntity.
     *
     * @param post the CloudEntity
     * @return author string
     */
    private String getAuthor(CloudEntity post) {
        if (post.getCreatedBy() != null) {
            return " " + post.getCreatedBy().replaceFirst("@.*", "");
        } else {
            return "<anonymous>";
        }
    }
}
