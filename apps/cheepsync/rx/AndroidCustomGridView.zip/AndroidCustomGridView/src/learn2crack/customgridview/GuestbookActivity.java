/*
 * Copyright (c) 2013 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package learn2crack.customgridview;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.cloud.backend.R;
import com.google.cloud.backend.core.CloudBackendFragment;
import com.google.cloud.backend.core.CloudBackendFragment.OnListener;
import com.google.cloud.backend.core.CloudCallbackHandler;
import com.google.cloud.backend.core.CloudEntity;
import com.google.cloud.backend.core.CloudQuery.Order;
import com.google.cloud.backend.core.CloudQuery.Scope;
import com.google.cloud.backend.core.Consts;
import org.apache.commons.*;
import org.apache.commons.math3.analysis.polynomials.PolynomialFunction;
import org.apache.commons.math3.optimization.fitting.CurveFitter;
import org.apache.commons.math3.optimization.general.LevenbergMarquardtOptimizer;


/**
 * Sample Guestbook app with Mobile Backend Starter.
 */
public class GuestbookActivity extends Activity implements OnListener {

    private static final String BROADCAST_PROP_DURATION = "duration";
    private static final String BROADCAST_PROP_MESSAGE = "message";

    private static final int INTRO_ACTIVITY_REQUEST_CODE = 1;

    private static final String PROCESSING_FRAGMENT_TAG = "BACKEND_FRAGMENT";
    private static final String SPLASH_FRAGMENT_TAG = "SPLASH_FRAGMENT";

    public static final String GUESTBOOK_SHARED_PREFS = "GUESTBOOK_SHARED_PREFS";
    public static final String SHOW_INTRO_PREFS_KEY = "SHOW_INTRO_PREFS_KEY";
    public static final String SCOPE_PREFS_KEY = "SCOPE_PREFS_KEY";

    private boolean showIntro = true;
    private Handler mHandler;
    private BluetoothAdapter mBluetoothAdapter;
    private boolean mScanning;
    private static final long SCAN_PERIOD = 10000;

    /*
     * UI components
     */
    private ListView mPostsView;
    private TextView mEmptyView;
    private EditText mMessageTxt;
    private ImageView mSendBtn;
    private TextView mAnnounceTxt;

    private FragmentManager mFragmentManager;
    private CloudBackendFragment mProcessingFragment;
    private SplashFragment mSplashFragment;

    /**
     * A list of posts to be displayed
     */
    private List<CloudEntity> mPosts = new LinkedList<CloudEntity>();
    boolean status=false;
    int number=0;
    ScheduledExecutorService scheduleExecutor;
    ScheduledFuture<?> scheduledFuture;
    
    
    
    ScheduledExecutorService scheduleExecutor1;
    ScheduledFuture<?> scheduledFuture1;
    
    ScheduledExecutorService scheduleExecutor2;
    ScheduledFuture<?> scheduledFuture2;
    
    static String name;
    private static BluetoothDevice device;
    //Should I send data or only receive it?
    static boolean master;
  //Store time on android phone
    static Time_Node time_complete;
    //Store current time of node
    static long node_time_current=0;
    //Points to the nano time when the device was discovered
    public static String current_nano="";
    //this variable is for telling us whether data upload is complete
    boolean set=false;
    public static HashMap<String, Time_Data> data_node;
    public double count_android;
    public double count_android1;
    double phone_seconds=0;
    String global_nano_time;
    Process process;
    Thread thread;
    String time_bt_userial[];
    Thread run;
    String time_difference[];
    HashMap<String,ArrayList<array_data>> mem;
    int flag=1;
    String log_viewer="";
    public static BluetoothDevice getDevice() {
		return device;
	}

	public static void setDevice(BluetoothDevice device) {
		GuestbookActivity.device = device;
	}

	/**
     * Override Activity lifecycle method.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //time=1;

        // Create the view
        mPostsView = (ListView) findViewById(R.id.posts_list);
        mEmptyView = (TextView) findViewById(R.id.no_messages);
        mMessageTxt = (EditText) findViewById(R.id.message);
        mMessageTxt.setHint("Type message");
        mMessageTxt.setEnabled(false);
        mSendBtn = (ImageView) findViewById(R.id.send_btn);
        mSendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onSendButtonPressed(v);
            }
        });
        mSendBtn.setEnabled(false);
        mAnnounceTxt = (TextView) findViewById(R.id.announce_text);
        
        mFragmentManager = getFragmentManager();

        checkForPreferences();
        loadPref();
        mHandler = new Handler();
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        //mBluetoothAdapter = bluetoothManager.getAdapter();
        		mBluetoothAdapter=bluetoothManager.getAdapter();
        scanInterval();
        //scanLeDevice(true);
        time_complete=new Time_Node();
        data_node=new HashMap<String,Time_Data>();
        //data_node_multi=new HashMap<String,Time_Data>();
        time_bt_userial=new String[1000];
        time_difference=new String[1000];
        //Create a temp array list to hold only a definite number of objects
        mem=new HashMap<String,ArrayList<array_data>>();
        toggleBluetooth();
        
        //executeContinuous();
//        run= new Thread()
//        {
//        	public void run()
//        	{
//        createLogFile();
//        dumpLastRecorded();
//        try {
//			readTimeStamps();
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//        	}
//        };
//        run.start();
//        
//        for(int i=0;i<100000;i++)
//        {
//        Log.d("hi","hello");
//        Log.d("Nano",getNanoTime1());
//        }
    }

    /**
     * Override Activity lifecycle method.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.activity_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    /**
     * Override Activity lifecycle method.
     */
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem loginItem = menu.findItem(R.id.switch_account);
        loginItem.setVisible(Consts.IS_AUTH_ENABLED);
        return true;
    }

    /**
     * Override Activity lifecycle method.
     * <p>
     * To add more option menu items in your client, add the item to menu/activity_main.xml,
     * and provide additional case statements in this method.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.switch_account:
                mProcessingFragment.signInAndSubscribe(true);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        this.showIntro = false;
    }

    /**
     * Override Activity lifecycle method.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // handle result codes
        if (requestCode == INTRO_ACTIVITY_REQUEST_CODE) {
            initiateFragments();
        }
        // call super method to ensure unhandled result codes are handled
        super.onActivityResult(requestCode, resultCode, data);
    }

    /**
     * Method called via OnListener in {@link CloudBackendFragment}.
     */
    @Override
    public void onCreateFinished() {
        listPosts();
        executeContinuous();
    }

    /**
     * Method called via OnListener in {@link CloudBackendFragment}.
     */
    @Override
    public void onBroadcastMessageReceived(List<CloudEntity> l) {
//        for (CloudEntity e : l) {
//            String message = (String) e.get(BROADCAST_PROP_MESSAGE);
//            int duration = Integer.parseInt((String) e.get(BROADCAST_PROP_DURATION));
//            Toast.makeText(this, message, duration).show();
//            Log.i(Consts.TAG, "A message was recieved with content: " + message);
//        }
    }

    private void initiateFragments() {
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();

        // Check to see if we have retained the fragment which handles
        // asynchronous backend calls
        mProcessingFragment = (CloudBackendFragment) mFragmentManager.
                findFragmentByTag(PROCESSING_FRAGMENT_TAG);
        // If not retained (or first time running), create a new one
        if (mProcessingFragment == null) {
            mProcessingFragment = new CloudBackendFragment();
            mProcessingFragment.setRetainInstance(true);
            fragmentTransaction.add(mProcessingFragment, PROCESSING_FRAGMENT_TAG);
        }

        // Add the splash screen fragment
            mSplashFragment = new SplashFragment();
            fragmentTransaction.add(R.id.activity_main, mSplashFragment, SPLASH_FRAGMENT_TAG);
            fragmentTransaction.commit();
    }

    private void checkForPreferences() {
        SharedPreferences settings =
                getSharedPreferences(GUESTBOOK_SHARED_PREFS, Context.MODE_PRIVATE);
        boolean showIntro = true;
        if (settings != null) {
            showIntro = settings.getBoolean(SHOW_INTRO_PREFS_KEY, true) && this.showIntro;
        }
        if (showIntro) {
            //Intent intent = new Intent(this, IntroductionActivity.class);
            //startActivityForResult(intent, INTRO_ACTIVITY_REQUEST_CODE);
            initiateFragments();
        } else {
            initiateFragments();
        }
    }

    /**
     * onClick method.
     */
    public void onSendButtonPressed(View view) {

        // create a CloudEntity with the new post
        CloudEntity newPost = new CloudEntity("Guestbook");
        newPost.put("message", mMessageTxt.getText().toString());

        // create a response handler that will receive the result or an error
        CloudCallbackHandler<CloudEntity> handler = new CloudCallbackHandler<CloudEntity>() {
            @Override
            public void onComplete(final CloudEntity result) {
                mPosts.add(0, result);
                updateGuestbookView();
                mMessageTxt.setText("");
                mMessageTxt.setEnabled(true);
                mSendBtn.setEnabled(true);
            }

            @Override
            public void onError(final IOException exception) {
                handleEndpointException(exception);
            }
        };

        // execute the insertion with the handler
        mProcessingFragment.getCloudBackend().insert(newPost, handler);
        mMessageTxt.setEnabled(false);
        mSendBtn.setEnabled(false);
    }
    
    
    
   public void onSendButtonPressed(final array_data fill,String nano_time) {
	   
        
        // create a CloudEntity with the new post
        CloudEntity newPost = new CloudEntity("Guestbook");
        newPost.put("message", mMessageTxt.getText().toString());
        status=true;
        //newPost.put("time",Long.toString(fill.getTime()));
        newPost.put("time", fill.getTime());
        newPost.put("mac_addr",fill.getDevice().getAddress());
        newPost.put("name", GuestbookActivity.name);
        //setDevice(fill.getDevice());
        //Lets 
        //We have the time at which the request was received
        newPost.put("android_millis", Long.toString(time_complete.getMillis()));
        newPost.put("android_second", Integer.toString(time_complete.getSeconds()));
        newPost.put("android_minute", Integer.toString(time_complete.getMinutes()));
        newPost.put("android_hour", Integer.toString(time_complete.getHours()));
        newPost.put("nano_time", fill.get_Android_Nano_Time());
        Log.d("compare",fill.get_Android_Nano_Time()+" "+nano_time);
        set=false;

        // create a response handler that will receive the result or an error
        CloudCallbackHandler<CloudEntity> handler = new CloudCallbackHandler<CloudEntity>() {
            @Override
            public void onComplete(final CloudEntity result) {
                mPosts.add(0, result);
                updateGuestbookView();
                mMessageTxt.setText("");
                mMessageTxt.setEnabled(true);
                mSendBtn.setEnabled(true);
                status=false;
            }

            @Override
            public void onError(final IOException exception) {
                handleEndpointException(exception);
            }
        };

        // execute the insertion with the handler
//        if(time==0 || status==flase)
//        {
//        mProcessingFragment.getCloudBackend().insert(newPost, handler);
//        mMessageTxt.setEnabled(false);
//        mSendBtn.setEnabled(false);
//        }
        
    

        		
        		if(master)
        		{
        			mProcessingFragment.getCloudBackend().insert(newPost,handler);
        			mMessageTxt.setEnabled(false);
        			mSendBtn.setEnabled(false);
        		}
        			
        		
        		
        	
   }

    
    
    
    
    
    
    
    
    
    
    
    

    /**
     * Retrieves the list of all posts from the backend and updates the UI. For
     * demonstration in this sample, the query that is executed is:
     * "SELECT * FROM Guestbook ORDER BY _createdAt DESC LIMIT 50" This query
     * will be re-executed when matching entity is updated.
     */
    private void listPosts() {
        // create a response handler that will receive the result or an error
    	//Lets not list posts for now
    	
        CloudCallbackHandler<List<CloudEntity>> handler =
                new CloudCallbackHandler<List<CloudEntity>>() {
                    @Override
                    public void onComplete(List<CloudEntity> results) {
                    	//This is where results are received for GCM messages
                    	Log.d("inside","in gcm");
                        mAnnounceTxt.setText(R.string.announce_success);
                        mPosts = results;
                        animateArrival();
                        updateGuestbookView();
                    }

                    @Override
                    public void onError(IOException exception) {
                        mAnnounceTxt.setText(R.string.announce_fail);
                        animateArrival();
                        handleEndpointException(exception);
                    }
                };
//
//        // execute the query with the handler
        mProcessingFragment.getCloudBackend().listByKind(
                "Guestbook", CloudEntity.PROP_CREATED_AT, Order.DESC, 10,
                Scope.FUTURE_AND_PAST, handler);
    	
    	//animateArrival();
    }

    private boolean firstArrival = true;
    private void animateArrival() {
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
        mSplashFragment = (SplashFragment) mFragmentManager.findFragmentByTag(
                SPLASH_FRAGMENT_TAG);
        if (mSplashFragment != null) {
            fragmentTransaction.remove(mSplashFragment);
            fragmentTransaction.commitAllowingStateLoss();
        }

        if (firstArrival) {
            mAnnounceTxt.setVisibility(View.VISIBLE);
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.translate_progress);
            anim.setAnimationListener(new Animation.AnimationListener() {
    
                @Override
                public void onAnimationStart(Animation animation) {
                }
    
                @Override
                public void onAnimationRepeat(Animation animation) {
                }
    
                @Override
                public void onAnimationEnd(Animation animation) {
                    mAnnounceTxt.setVisibility(View.GONE);
                }
            });
            mAnnounceTxt.startAnimation(anim);
            firstArrival = false;
        }
    }

    private void updateGuestbookView() {
            mMessageTxt.setEnabled(true);
            mSendBtn.setEnabled(true);
            if (!mPosts.isEmpty()) {
                mEmptyView.setVisibility(View.GONE);
                mPostsView.setVisibility(View.VISIBLE);
                mPostsView.setAdapter(new PostAdapter(
                        this, android.R.layout.simple_list_item_1, mPosts));
            } else {
                mEmptyView.setVisibility(View.VISIBLE);
                mPostsView.setVisibility(View.GONE);
            }
    }

    private void handleEndpointException(IOException e) {
        Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
        mSendBtn.setEnabled(true);
    }
    
    
    private void scanLeDevice(final boolean enable) {
        if (enable) {
            // Stops scanning after a pre-defined scan period.
        	
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mScanning = false;
                    try
                    {
                    mBluetoothAdapter.stopLeScan(mLeScanCallback);
                    if(!mBluetoothAdapter.isEnabled())
                    {
                    	mBluetoothAdapter.enable();
                    }
                    }
                    catch(Exception e)
                    {
                    	
                    }
                    //invalidateOptionsMenu();
                }
            }, SCAN_PERIOD);

            mScanning = true;
            mBluetoothAdapter.startLeScan(mLeScanCallback);
        } else {
            mScanning = false;
            mBluetoothAdapter.stopLeScan(mLeScanCallback);
        }
        //invalidateOptionsMenu();
    }
    
    
    
    private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback() {

        @Override
        public void onLeScan(final BluetoothDevice device, final int rssi, final byte[] scanRecord) {
        	//get time first
        	Thread temp=new Thread()
        	{
        		public void run()
        		{
        	String current_nano=getNanoTime1();
        	BluetoothDeviceTemp dev_temp=new BluetoothDeviceTemp();
        	dev_temp.setDevice_addr(device.getAddress());
        	dev_temp.setName(device.getName());
        	byte[] scan_temp=scanRecord.clone();
        	Log.d("inthis","**************************************");
        	runOnThread(dev_temp,rssi,scan_temp,current_nano);
            Log.d("inthis","**************************************");
        		}
        	};
        	temp.start();
        }
        
    };
    
    
    
    public void scanInterval()
    {
//    	ScheduledExecutorService scheduleTaskExecutor = Executors.newScheduledThreadPool(5);
//
//    	scheduleTaskExecutor.scheduleAtFixedRate(new Runnable() {
//    	  public void run() {
//    		  Log.d("Inside","in");
//    	    scanLeDevice(true);
//    	  }
//    	}, 0, 2, TimeUnit.MINUTES);
    	

    			 scheduleExecutor=Executors.newScheduledThreadPool(5);

    			  scheduledFuture =scheduleExecutor.scheduleAtFixedRate(new Runnable(){
    				public void run()
    				{
    					Log.d("in","inside");
    					//scanLeDevice(true);
    						if(mScanning==false)
    						{
    							scanLeDevice(true);
    							//data_node.clear();
    						}
    					//scanLeDevice(true);
    					
    				}
    			},0,1000,TimeUnit.MILLISECONDS);
    			  
    			  
    			  
    			  
//    			  scheduledFuture1 =scheduleExecutor.scheduleAtFixedRate(new Runnable(){
//      				public void run()
//      				{
//      					//Log.d("count",Double.toString(count));
//      					//Log.d("count",Double.toString(count_android));
//      					count_android++;
//      					Log.d("timeis",getNanoTime());
//      					
//      				}
//      			},0,10,TimeUnit.NANOSECONDS);
//    			  
    			  
    			  
    			  
    			  
    			  
    			  
    			  
    			  
    			  
    			  
    			  
//    			  scheduledFuture1 =scheduleExecutor.scheduleAtFixedRate(new Runnable(){
//				public void run()
//				{
//					//Log.d("count",Double.toString(count));
//					//Log.d("count",Double.toString(count_android));
//					global_nano_time=getNanoTime1();
//					//Log.d("time_is_nooooooo", global_nano_time);
//					
//				}
//			},0,100,TimeUnit.MICROSECONDS);
//    			  
    			  
    			  
    			  
    			  
    			  scheduledFuture2 =scheduleExecutor.scheduleAtFixedRate(new Runnable(){
        				public void run()
        				{
        					//Log.d("count",Double.toString(count));
        					//Log.d("count",Double.toString(count_android));
        					count_android1++;
        					
        				}
        			},0,1000,TimeUnit.MILLISECONDS);
    			  
    			  
    			
    }

	@Override
	public void finish() {
		// TODO Auto-generated method stub
		//scheduleExecutor.cancel();
		//scheduleExecutor
		//scheduleFuto
		//scheduleFuture.cancel(false);
		//schedulle
		scheduledFuture.cancel(false);
		//scheduledFuture1.cancel(false);
		scheduledFuture2.cancel(false);
		Log.d("killing","done");
//		thread.interrupt();
//		run.interrupt();
//		run=null;
//		thread=null;
//		process.destroy();
//		try {
//			Runtime.getRuntime().exec("su -c killall logcat");
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		//process.
		
		super.finish();
	}
	
	
	 private void loadPref(){
		  SharedPreferences mySharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
		  
		  boolean my_checkbox_preference = mySharedPreferences.getBoolean("checkbox_preference", false);
		  //prefCheckBox.setChecked(my_checkbox_preference);

		  name = mySharedPreferences.getString("edittext_preference", "");
		  //prefEditText.setText(my_edittext_preference);
		  master=my_checkbox_preference;

		 }
	 
	 
	 
	 
	 
	 
	 	double estimateKDynamic(double phone_elapsed,double node_count)
	 	{
	 		//This function determines the theritical value of k for the results 
	 		//to be as close to 0 as possible
	 		//accepts an array list
	 		//does evaluation of vlaue of k on the diff_time
	 		//Find the best value of k
	 		//assume k between 0.096 and 0.102
	 		//TODO:Make scale postive so that 
	 		double sum=0;
	 		double min=10000.0;
	 		double to_return=0.0;
	 		flag=0;
	 		double i=0;
	 		 //i=0.000196;i<0.000202;i=i+0.00000001
	 		//i=0.096;i<0.102;i=i+0.000001
	 		for(i=0.096;i<0.102;i=i+0.000001)
	 		{
	 			sum=phone_elapsed-(node_count)*i;
	 			sum=Math.abs(sum);
	 			//Log.d("te"," "+sum+" "+i);
	 			//We have to make sure sum is positive
	 			if(sum<min)
	 			{
	 				min=sum;
	 				//Return value of k
	 				to_return=i;
	 			}
	 		}
	 		Log.d("inthis","insidedjkfhkjhffdkjldkhd");
	 		flag=1;
	 		Log.d("last",""+i);
	 		return to_return;
	 		
	 		
	 	}
	 

	 
	 
	 
	 
	
	 
	 public void setTime()
		{
			int seconds;
			int hours;
			int minutes;
			long millis;
			Calendar c = Calendar.getInstance(); 
			 seconds = c.get(Calendar.SECOND);
			time_complete.setSeconds(seconds);
			 minutes=c.get(Calendar.MINUTE);
			 time_complete.setMinutes(minutes);
		     hours=c.get(Calendar.HOUR);
		     time_complete.setHours(hours);
					//The input_time is in milli seconds
					//So we will calculate offset in miiliseconds
					 millis=c.get(Calendar.MILLISECOND);
					 time_complete.setMillis(millis);
					Log.d("milli",Long.toString(millis));
					//return time;
			
			
		}
	 
	 
	 
	 
	 public static Time_Node getTime()
	 {
		 return time_complete;
	 }
	 
	 public String getNanoTime()
	 {
		 String result;
		 //double start=System.nanoTime();
		 result=getString(1,2);
		 //Log.d("Time i")
		 //Log.d("time",result);
		 //double end=System.nanoTime();
		 //Log.d("time",Double.toString(start-end));
		 //double actual_time=Double.parseDouble(result)-((end-start)*Math.pow(10, -9));
		 //double actual_time=Double.parseDouble(result)-((end-start)*Math.pow(10, -9));
		 //if(end-start > Math.pow(10,8))
			 //Log.d("Greater","in");
		 //return Double.toString(actual_time);
			 
	   double millis= (double)System.currentTimeMillis()/1000;
	   Log.d("time_millis",""+millis);
	   return Double.toString(millis);
 
		// return result;

		 
		 
	 }
	 
	 
	 
	 public String getNanoTime1()
	 {
		 String result;
		 //double start=System.nanoTime();
		 result=getString(1,2);
		 //Log.d("Time i")
		 //Log.d("time",result);
		 //double end=System.nanoTime();
		 //Log.d("time",Double.toString(start-end));
		 //double actual_time=Double.parseDouble(result)-((end-start)*Math.pow(10, -9));
		 //double actual_time=Double.parseDouble(result)-((end-start)*Math.pow(10, -9));
		 //if(end-start > Math.pow(10,8))
			 //Log.d("Greater","in");
		 //return Double.toString(actual_time);
			 

 
		 return result;

		 
		 
	 }
	 
	 
	 public void createLogFile()
	 {
		 
		  thread = new Thread()
		 {
			 public void run()
			 {
				 try
				 {
					 process = Runtime.getRuntime().exec("su -c logcat -s \"bt_userial\" | grep -ve \"is\" -e \"in\" -e \"Calledssss\" > /sdcard/log.txt");
				      
				 }
				 catch(Exception e)
				 {
					 
				 }
			 }
		 };
		 thread.start();
		
	 }
	 
	 
	 public void dumpLastRecorded()
	 {
		//Dump the last 50 timestamps using the tail command
		 
		 try {
			 //Runtime.getRuntime().exec("su -c rm /sdcard/log_temp.txt");
			 try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Process dump=Runtime.getRuntime().exec("su -c tail -n 500 /sdcard/test.txt > /sdcard/log_temp.txt ");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		 
		 
	 }
	 
	 //The main log function which logs the difference in timestamps received
	 public double[]  logCorrectValue(String current_time_stamp,String count,String transmit_time,String time_bt_userial[])
	 {
		 //We need a generic way to get this logged
		 //So that we may import it into matlab
		 //We therefore need to separate these by spaces
		 //For now I think if we print 4 rows that would be ebough
		 int k=0;
		 String result = "";
		for(int i=0;i<99;i++)
		{
		  time_bt_userial[i]=time_bt_userial[i].replaceAll("\\s","");
		  //Log.d("bt_user_data_app",i+" "+time_bt_userial[i]+  " "+current_time_stamp);
		                           
		}
		
		double current_time=Double.parseDouble(current_time_stamp);
		for(int i=0;i<99;i++)
		{
			double difference=Double.parseDouble(time_bt_userial[i])-current_time;
			//Log.d("difference"," "+difference);
			if( (difference<0) && (difference)>-1)
			{
				Log.d("k"," "+k);
				time_difference[k]=Double.toString((Double.parseDouble(time_bt_userial[i])-current_time));
				k++;
			}
			
		}
		Log.d("k","vlue is "+k);
		for(int i=0;i<k;i++)
		{
			result=result+ time_difference[i]+" ";
		}
		
		  Log.d("diff",result);
		  log_viewer=result;
		 
		 //We return the minimum value present in the time_difference
		 double[] diff_temp = new double[k];
		 for (int i = 0; i < k; i++) {
			 
		     diff_temp[i] = Double.parseDouble(time_difference[i]);
		     Log.d("spade"," "+diff_temp[i]);
		 }
		 
		 //return diff_temp[k-1];
		 //return getMaxValue(diff_temp);
		 //return result;
		 return diff_temp;
		  //return 1;
	 }
	 
	 
	 public  double getMinValue(double[] numbers){  
		  double minValue = numbers[0];  
		  for(int i=1;i<numbers.length;i++){  
		    if(numbers[i] < minValue){  
		      minValue = numbers[i];  
		    }  
		  }  
		  return minValue; 
	 }
	 
	 
	 public double getMaxValue(double [] numbers)
	 {
		 double max;
		 max=numbers[0];
		 for(int i=0;i<numbers.length;i++)
		 {
			 if(numbers[i]>max)
			 {
				 max=numbers[i];
			 }
		 }
		 return max;
	 }
	 
	 
	 public double[] readTimeStamps(String timestamp,String count,String tt) throws FileNotFoundException
	 {
		 //This reads the timestamp generated at bt_userial
//		  Scanner read= new Scanner(new File("/sdcard/log_temp.txt"));
//		  String tag,data = null;
//		  int i=0;
//
//		
//		while(read.hasNextLine())
//		{
//			//tag=read.nextLine();
//			//StringTokenizer tokenizer=new StringTokenizer(tag,":");
//			
//				try
//				{
//					//Log.d("element",tokenizer.nextElement().toString());
//					time_bt_userial[i]=read.nextLine().toString();
//                    Log.d("element1",time_bt_userial[i]);
//                    Log.d("element1","i s"+i);
//                    i++;
//					
//					
//				
//				}
//				catch(Exception e)
//				{
//					//Log.d("element",e.getMessage());
//					Log.d("Exception", "in");
//				}
//			
//			
//			
//		}
//			   read.close();
		 File file = new File("/sdcard/test.txt");
		 //Log.d("lines",tail2(file, 10));
		 String time_bt_userial[] = tail2(file,100).split("\n");
		 //Log.d("lines",Arrays.toString(time_bt_userial));
		 //Log.d("length",Integer.toString(time_bt_userial.length));
		 double min[] =logCorrectValue(timestamp, count,tt,time_bt_userial);
		 Log.d("Min"," "+min);
		 return min;
			   
		 
	 }
	 
	 double[] getResults(String timestamp,String count,String tt)
	 {
		 //This will be called from BLE on complete
//		 Thread temp=new Thread()
//		 {
//			 //Log file already created
//			 public void run()
//			 {
//			
//		 //dumpLastRecorded();
//	        
//	        
//	        
//			 }
//		 };
//		 temp.start();
//		 //Log the value

		 try {
			return 	readTimeStamps( timestamp, count, tt);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return null;
		 
		 
		 
	 }
	 
	 
	 
	 
	 void toggleBluetooth()
	 {
		 
		  ScheduledExecutorService scheduleExecutor_toggle=Executors.newScheduledThreadPool(5);
		  ScheduledFuture<?> scheduled_toggle =scheduleExecutor_toggle.scheduleAtFixedRate(new Runnable(){
			public void run()
			{
				//Toggle bluetooth
				Log.d("toggle","toggling");
				BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();    
				if (mBluetoothAdapter.isEnabled()) {
				    mBluetoothAdapter.disable(); 
				} 
				//Assume it takes 2 seconds
			   try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
				
			   mBluetoothAdapter.enable();
			   mBluetoothAdapter.enable();
			   mBluetoothAdapter.enable();
				
				
				
				
				
				
				
			}
		},0,600,TimeUnit.SECONDS);
		 
	 }
	 
	 public void appendLog(String text)
	 {       
	    File logFile = new File("sdcard/log_after.file");
	    if (!logFile.exists())
	    {
	       try
	       {
	          logFile.createNewFile();
	       } 
	       catch (IOException e)
	       {
	          // TODO Auto-generated catch block
	          e.printStackTrace();
	       }
	    }
	    try
	    {
	       //BufferedWriter for performance, true to set append to file flag
	       BufferedWriter buf = new BufferedWriter(new FileWriter(logFile, true)); 
	       buf.append(text);
	       buf.newLine();
	       buf.close();
	    }
	    catch (IOException e)
	    {
	       // TODO Auto-generated catch block
	       e.printStackTrace();
	    }
	 }
	 
	 
	 
	 
	 
public void appendLogMulti(String text)	 
	 {       
	    File file =new File("/sdcard/multi_file.file");
	    if (!file.exists())
	    {
	       try
	       {
	          file.createNewFile();
	       } 
	       catch (IOException e)
	       {
	          // TODO Auto-generated catch block
	          e.printStackTrace();
	       }
	    }
	    try
	    {
	       //BufferedWriter for performance, true to set append to file flag
	       BufferedWriter buf = new BufferedWriter(new FileWriter(file, true)); 
	       buf.append(text);
	       buf.newLine();
	       buf.close();
	    }
	    catch (IOException e)
	    {
	       // TODO Auto-generated catch block
	       e.printStackTrace();
	    }
	 }
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 public void appendLogBeforeCorrection(String text)
	 {       
	    File logFile = new File("sdcard/log_before.file");
	    if (!logFile.exists())
	    {
	       try
	       {
	          logFile.createNewFile();
	       } 
	       catch (IOException e)
	       {
	          // TODO Auto-generated catch block
	          e.printStackTrace();
	       }
	    }
	    try
	    {
	       //BufferedWriter for performance, true to set append to file flag
	       BufferedWriter buf = new BufferedWriter(new FileWriter(logFile, true)); 
	       buf.append(text);
	       buf.newLine();
	       buf.close();
	    }
	    catch (IOException e)
	    {
	       // TODO Auto-generated catch block
	       e.printStackTrace();
	    }
	 }
	 
	 
	 
	 
	 
	 
	 
	 
	 public String tail2( File file, int lines) {
		    java.io.RandomAccessFile fileHandler = null;
		    try {
		        fileHandler = 
		            new java.io.RandomAccessFile( file, "r" );
		        long fileLength = fileHandler.length() - 1;
		        StringBuilder sb = new StringBuilder();
		        int line = 0;

		        for(long filePointer = fileLength; filePointer != -1; filePointer--){
		            fileHandler.seek( filePointer );
		            int readByte = fileHandler.readByte();

		            if( readByte == 0xA ) {
		                line = line + 1;
		                if (line == lines) {
		                    if (filePointer == fileLength) {
		                        continue;
		                    }
		                    break;
		                }
		            } else if( readByte == 0xD ) {
		                line = line + 1;
		                if (line == lines) {
		                    if (filePointer == fileLength - 1) {
		                        continue;
		                    }
		                    break;
		                }
		            }
		            sb.append( ( char ) readByte );
		        }

		        String lastLine = sb.reverse().toString();
		        return lastLine;
		    } catch( java.io.FileNotFoundException e ) {
		        e.printStackTrace();
		        return null;
		    } catch( java.io.IOException e ) {
		        e.printStackTrace();
		        return null;
		    }
		    finally {
		        if (fileHandler != null )
		            try {
		                fileHandler.close();
		            } catch (IOException e) {
		            }
		    }
		}
	 
	void estimateScale(List<CloudEntity> results)
	{
		//This function calculates and estimates the value of k
		//using data stored on the cloud
		//Loop through all elements and check them out
		Double phone_time[]=new Double[50];
		Double node_count[]=new Double[50];
		Log.d("running1","in");
		int k=0;
		for(CloudEntity ce: results)
		{
			try
			{
			Log.d("running1","in");
			phone_time[k]=Double.parseDouble(ce.get("nano_time").toString());
			node_count[k]=Double.parseDouble(ce.get("time".toString()).toString());
			k++;
			}
			catch(Exception e)
			{
				Log.d("running1",e.getMessage());
			}
					
		}
		Log.d("running1",Arrays.toString(phone_time));
		Log.d("running1",Arrays.toString(node_count));
		//Find how to determine value of k from the above phone_time and node_time
		//Lets assume that we hardcode the values right now
		//Later we will use our own custom api's in order to estimate the value of k
		
		for(int i=0;i<9;i++)
		{
			phone_time[i+1]=phone_time[0]-phone_time[i+1];
		}
		for(int i=0;i<9;i++)
		{
			node_count[i+1]=node_count[0]-node_count[i+1];
		}
		phone_time[0]=0.0;
		node_count[0]=0.0;
		Log.d("running1",Arrays.toString(phone_time));
		Log.d("running1",Arrays.toString(node_count));
        double scale=200/1000000;
        double sum=0;
        double min=100;
        double new_scale=0;
        for(scale=(double)198/1000000;scale<(double)200/1000000;scale=scale+0.000000001)
        {
        	Log.d("running1"," "+scale);
        	sum=0;
        	for(int i=0;i<10;i++)
        	{
        		sum=sum+Math.abs((double)phone_time[i]-(double)node_count[i]*scale);
        		
        	}
        	Log.d("running1",Double.toString(sum));
        	if(sum<min)
        	{
        		min=sum;
        		new_scale=scale;
        	}
        }
	  Log.d("running1", Double.toString(new_scale));
				
				
		
		
	}
	 
	 
	 private void listPostsForScale() {
	        // create a response handler that will receive the result or an error
	    	//Lets not list posts for now
	    	
	        CloudCallbackHandler<List<CloudEntity>> handler =
	                new CloudCallbackHandler<List<CloudEntity>>() {
	                    @Override
	                    public void onComplete(List<CloudEntity> results) {
	                    	Log.d("inside","in gcm");
	                        mAnnounceTxt.setText(R.string.announce_success);
	                        mPosts = results;
	                        Log.d("running",results.toString());
	                        Log.d("running1","calling");
	                        //estimateScale(results);
	                        //animateArrival();
	                        //This function gets called to receive messages
	                        //if(!master)
	                        //updateGuestbookView();
	                        //This function gets called every 5 seconds
	                        //We have to determine the time difference between that on the node and that on the phone
	                        if(!master)
	                        {
	                        	updateGuestbookView();
	                        	logMultiplePhone(results);
	                        }
	                    }

	                    @Override
	                    public void onError(IOException exception) {
	                    	Log.d("running","error");
	                        mAnnounceTxt.setText(R.string.announce_fail);
	                        //animateArrival();
	                        handleEndpointException(exception);
	                    }
	                };
	//
	        // execute the query with the handler
	        mProcessingFragment.getCloudBackend().listByKind(
	                "Guestbook", CloudEntity.PROP_CREATED_AT, Order.DESC, 10,
	                Scope.FUTURE_AND_PAST, handler);
	    	
	    	//animateArrival();
	    }
	 
	 
	 void executeContinuous()
	 {
		 //listPostsForScale();
		 ScheduledExecutorService scheduleExecutor_scale=Executors.newScheduledThreadPool(5);
		 ScheduledFuture<?> scheduledFuture_scale =scheduleExecutor_scale.scheduleAtFixedRate(new Runnable(){
				public void run()
				{
					Log.d("running","kdjfl");
				try
				{
					runOnUiThread(new Runnable() {

                        @Override
                        public void run() {
                        	listPostsForScale();
                        }
                    });
					
						//listPosts();
				}
				catch(Exception e)
				{
					Log.d("running",e.getMessage().toString());
				}
					
					
					
				}
			},0,5,TimeUnit.SECONDS);
	 }
	 
	 
	 
	 
	 
	 

void logMultiplePhone(List <CloudEntity> input)
{
	//This function logs the time difference between node and phone
	//It Accepts a cloud entity input which is a list of 10 previous messages
	//It logs to file only if the message received is a new message
	CloudEntity data=input.get(0);

	
	try
	{
		//This is the time at which data was inserted

		String android_time=data.get("nano_time").toString();
		String node_time=data.get("time").toString();
		//We need to get current value of counter as well as timestamp
		String current_android_time=GuestbookActivity.data_node.get(data.get("mac_addr")).getAndroid_nano_time();
		String current_node_time=GuestbookActivity.data_node.get(data.get("mac_addr")).getNode_time();
		//Now we find the actual time elapsed
		//Always use doubles
		double prev_android_nano_time=Double.parseDouble(android_time);
		
		double current_android_nano_time=Double.parseDouble(current_android_time);
		//time elapsed
		double elapsed=current_android_nano_time-prev_android_nano_time;
		//elapsed=elapsed*Math.pow(10, 6);
		double prev_node_time=Double.parseDouble(node_time);
		double current_node_time_count=Double.parseDouble(current_node_time);
		double node_elapsed=current_node_time_count-prev_node_time;
		double check_k=estimateKDynamic(elapsed, node_elapsed);
		node_elapsed=node_elapsed*check_k;
		Log.d("phoneer"," "+check_k);
		if(elapsed<0)
		{
			Log.d("data3","negative");
			elapsed=elapsed*-1;
		}
		if(node_elapsed<0)
		{
			Log.d("data3","negative");
			node_elapsed=node_elapsed*-1;
		}
		double diff=elapsed-node_elapsed;
		Log.d("phoneer"," "+diff);
		Log.d("phoneer"," "+"android time "+elapsed+" node "+node_elapsed);
		Log.d("multidata"," android get "+android_time+" node_get "+node_time+" android "+current_android_time+" node "+current_node_time);
		appendLogMulti(data.get("mac_addr")+" "+diff+" "+current_android_time);

		

		
		
		
	}
     
	catch(Exception e)
	{
		Log.d("Entry","entered");
	}
     
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
}
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 public void runOnThread(final BluetoothDeviceTemp device, int rssi, final byte[] scanRecord,final String current_nano)
	 {
		 //This function is called from BLE on complete to avoid GKI exceptions
		 Thread ble_onComplete=new Thread()
		 {
			 public void run()
			 {
				 try
				 {

			            String s="";
			            String byte_neg_pos="";
			            
			            //Immeadiately set the time
			            //current_nano=getNanoTime1();
			            //current_nano=getNanoTime();

			            Log.d("Data_Number",Double.toString(Double.parseDouble(current_nano)));
			            //current_nano=global_nano_time;
			            if(phone_seconds==0)
			            {
			            	phone_seconds=Double.parseDouble(current_nano);
			            }
			            //Log.d("count is "+Double.toString(count_android));
			            //Log.d("count is",Double.toString(count_android));
			            //Log.d("phon_coun",Double.toString(count_android-count_android1));
			            		//long time_start=System.nanoTime();
			            //setTime();
			            //Instead of calling set time we call get nano time
			            		//String data[]=new String [scanRecord.length];
//			            for(int i=0;i<scanRecord.length;i++)
//			            {
//			            	s=s+scanRecord[i];
//			            	data[i]=String.format("%x",scanRecord[i]);
//			            }
//			            s="";
//			            for(int i=0;i<scanRecord.length;i++)
//			            {
//			            	//s=s+String.format("%x", scanRecord[i]);
//			            	//s=s+String.format("%x", scanRecod)
//			            			s=s+String.format("%x ", scanRecord[i]);
//			            }
			            //s = s.replaceAll("..", "$0 ");
			            //s=s.replaceAll("..", "$0");
			            //s=s.replaceAll(".", "$0 ");
			            //Log.i("Datas",s);
			            //Log.i("data",Arrays.toString(scanRecord));
			            //We parse the representation of the data. Let use create a separate class for it later
			            //Right now we need only fields 10,11,12
			            //10 is LSB and so on 
			             long time = 0;
			            				//time=scanRecord[10]+scanRecord[11]*256l+scanRecord[12]*65536l;
			            
			          
			            
			            
			            for(int i=13;i<=15;i++)
			            {
			            	//int data=scanRecord[i]&& oxff
			            	int data1=0;

			            		//data1=unsignedToBytes(scanRecord[i]);
			            	Log.d("grimm","data is "+scanRecord[i]);
			            	if(scanRecord[i]<0)
			            	{
			            		byte_neg_pos="neg";
			            		Log.d("grimm","neg");
			            	}
			            	else
			            	{
			            		byte_neg_pos="pos";
			            		Log.d("grimm","pos");
			            	}
			            		data1=unsignedToBytes(scanRecord[i]);
			            			
			            			
//			            			if(scanRecord[i]<0)
//			            				data1=256+scanRecord[i];
//			            			else
//			            				data1=scanRecord[i];
			            			Log.d("grimm",Integer.toString(data1));
			            		
			            		if(i==13)
			            			time=time+data1;
			            		else if(i==14)
			            			time=time+((long)data1*(long)256);
			            		else if(i==15)
			            			time=time+((long)data1*(long)65536);
			            }
			            Log.d("grimm",Long.toString(time)+" "+byte_neg_pos);          
			         
			          Log.d("FTSP","phone is "+(Double.parseDouble(current_nano)-phone_seconds)+"node is"+time);
			            
			            //Log.d("t")ime
			            //Log.d("time",Long.toString)
			            //set time of global time_stamp
			            		//time_node_current=time;
			            
			            		node_time_current=time;
			            
			            		//long time_end=System.nanoTime();
			            		//long time_elapsed=time_end-time_start;
			            		//Log.d("data1","time elapsed "+Long.toString(time_elapsed)+" "+(Double.parseDouble(current_nano)-phone_seconds));
			            				//double time_actual;
			            				//time_actual=time-(double)(time_elapsed/Math.pow(10, 9));
			            				//time_actual=Double.parseDouble(current_nano);
			            		//Subtract from node_time_current
			            		//time_elapsed is time taken to compute count
			            		
//			            int sum=0;
//			            sum=scanRecord[10]+scanRecord[11]+scanRecord[12];
//			            
//			            		Log.d("sum",Integer.toString(sum));
//			            
//			            Log.d("time",Long.toString(time));
			            int transmit_time=unsignedToBytes(scanRecord[16]);
			            double min[]=getResults(current_nano,Long.toString(time),Integer.toString(transmit_time));
			            //We now have to change the current_nano value 
			            //We decrease it by min
			            //current_nano=Double.toString((Double.parseDouble(current_nano)+min));
			            //assume delay of 0.018
			            //current_nano=Double.toString((Double.parseDouble(current_nano)-0.018));
			            Log.d("dddsss","");
			            final array_data fill=new array_data();
			        	fill.setDeviceBluetooth(device);
			        	fill.setTime(Long.toString(time));
			        	//fill.setTime(Double.toString(time_actual));
			        	fill.setAndroid_Nano_Time(Double.toString(Double.parseDouble(current_nano)+min[min.length-1]));
			        	//fill.setAndroid_Nano_Time_Push(Double.toString(Double.parseDouble(current_nano)+min[0]));
			        	fill.setDiff_time(min);
			          	Log.d("nano_time",Double.toString(Double.parseDouble(fill.get_Android_Nano_Time())-1402800000));
			          	//Lets calculate offset on one phone
			        	//onSendButtonPresses(time);
			          	//Log.d("phone_offset",Double.toString((double)(count_android/10)-(time*Math.pow(10, -1))));
			        	//Put data in our hash map
			        	//node_data.put(device.getAddress(),time);
			        	//For now lest assume that we are operating with only 1 node present
			          	//We therefore use size 2 only
			          	for(int i=0;i<min.length;i++)
			          		Log.d("min"," "+min[i]);
			          	Log.d("min","  ");
			        	data_node.put(device.getAddress(), new Time_Data(Double.toString(Double.parseDouble(current_nano)+min[min.length-1]),Double.toString((time))));
			        	//data_node_multi.put(device.getAddress(), new Time_Data(Double.toString(Double.parseDouble(current_nano)),Double.toString(time)));
			        	//Lets create a temporary ArrayList
			        	Log.d("size","inside");
			        	//Once we create a temporary array list we populate it 
			        	ArrayList<array_data> temp = null;
			        	try
			        	{
			        	temp=mem.get(device.getAddress());
			        	}
			        	
			        	catch(Exception e)
			        	{
			        		Log.d("size","inside");
			        	}
			        	if(temp==null)
			        	{
			        		Log.d("size","bo");
			        		ArrayList<array_data> data=new ArrayList<array_data>();
			        		data.add(fill);
			        		mem.put(device.getAddress(), data);
			        	}
			        	//Check if array list is empty
			        	try
			        	{
			        	Log.d("size","bla"+temp.size());
			        	}
			        	catch(Exception e)
			        	{
			        		Log.d("size","exc");
			        	}
			        	if(temp.size()==0)
			        	{
			        		//Array List empty
			        		//Insert the new array list and do some stuff
			        	    Log.d("size","0");
			        		
			        	}
			        	
//			        	if(mem.size()==0)
//			        	{
//			        		//First time
//			        		mem.put(device.getAddress(),fill);
//			        	}
//			        	else if(mem.size()==1)
//			        	{
//			        		mem.add(fill);
//			        		
//			        	}
//			        	else
//			        	{
//			        		array_data temp;
//			        		temp=mem.get(1);
//			        		mem.clear();
//			        		mem.add(0,temp);
//			        		mem.add(1,fill);
//			        	}
			        	else if(temp.size()==1)
			        	{
			        		//Array list already created
			        		//Get array list and insert next element
			        		Log.d("size","in 1");
			        		temp.add(fill);
			        		mem.put(device.getAddress(),temp);
			        	}
			        	else
			        	{
			        		Log.d("size","2");
			        		array_data temp_fill;
			        		temp_fill=temp.get(1);
			        		temp.clear();
			        		temp.add(0,temp_fill);
			        		temp.add(1,fill);
			        		mem.put(device.getAddress(),temp);
			        		
			        	}
			        	
			        	//mem is populated
			        	Log.d("size"," "+mem.size());
			        	if(mem.get(device.getAddress()).size()==2)
			        	{
			        		//Once mem is populated
			        		//We now find the time elapsed on count
			        		double node_elapsed;
			        		double phone_elapsed;
			        		double diff;
			        		double diff_time0[];
			        		double diff_time1[];
			                BigDecimal n1 = new BigDecimal(mem.get(device.getAddress()).get(1).getTime());
			                BigDecimal n0 = new BigDecimal(mem.get(device.getAddress()).get(0).getTime());
			                Log.d("change",n1.toString()+" "+n0.toString());
			                BigDecimal n3 = new BigDecimal(0);
			                n3=n1.subtract(n0);
			                Log.d("change","n3 "+n3.toString());
			        		//node_elapsed=Double.parseDouble(mem.get(1).getTime()) - Double.parseDouble(mem.get(0).getTime());
			                MathContext mc = new MathContext(3); 
			                
			                
			        		//node_elapsed=n3.doubleValue();
			                //node_elapsed=node_elapsed*0.099;
			        		//node_elapsed is in seconds
			        		//We now have to find the best values of k
			        		phone_elapsed=Double.parseDouble(mem.get(device.getAddress()).get(1).get_Android_Nano_Time())-Double.parseDouble(mem.get(device.getAddress()).get(0).get_Android_Nano_Time());
			        		//estimate value of k dynamically
			        		double node_count=n3.doubleValue();
			        		double dynamic_k=estimateKDynamic(phone_elapsed, n3.doubleValue());
			        		Log.d("cal",Double.toString(dynamic_k));
			        		//n3 holds the node_elapsed
			        		n3=n3.multiply(new BigDecimal(dynamic_k,mc));
			        		//We have time elpased on both devices
			        		//find the difference between phone and node elapsed
			                BigDecimal b1 = new BigDecimal(mem.get(device.getAddress()).get(1).get_Android_Nano_Time());
			                BigDecimal b0 = new BigDecimal(mem.get(device.getAddress()).get(0).get_Android_Nano_Time());
			                BigDecimal b3 = new BigDecimal(3.521);
			                BigDecimal b4 = new BigDecimal(0);
			                //node_elapsed
			                BigDecimal b5 = new BigDecimal(n3.toString());
			                //b3 phone_elapsed
			                b3=b1.subtract(b0);
			                //b4 phone_elapsed-node_elapsed
			        		b4=b3.subtract(b5);
			        		diff=b4.doubleValue();
			        		Log.d("bla"," "+mem.get(device.getAddress()).get(0).get_Android_Nano_Time());
			        		Log.d("change"," phone"+b3.toString()+ " node "+n3.toString()+" diff "+b4.toString());
			        		//Now we should choose values from diff so that this beacomes as close
			        		//to 0 as possible
			        		//Set above Search for fill.set
			        		diff_time1=mem.get(device.getAddress()).get(1).getDiff_time();
			        		diff_time0=mem.get(device.getAddress()).get(0).getDiff_time();
			        		//We have 2 arrays
			        		//We have to move through these arrays to find the 
			        		//sum such that diff becomes as small as possible 
			        		int k1;
			        		int k2;
			        		double cal=100;
			        		double offset0;
			        		double offset1;
			        		double temp1;
			        		offset0=diff_time0[diff_time0.length-1];
			        		offset1=diff_time1[diff_time1.length-1];
			        		temp1=offset1-offset0;
			        		Log.d("temp","0 "+offset0+"1 "+offset1+" "+temp1);
			        		String hold = "";
			        		//double temp;
			        		double temp_hold=0;
			        		temp_hold=temp1;
//			        		
//			        		for(int i=0;i<diff_time0.length;i++)
//			        		{
//			        			for(int j=0;j<diff_time1.length;j++)
//			        			{
//			        				
//			        			    temp_hold=diff_time0[i]-diff_time1[j];
//			        				hold=hold+" "+temp_hold;
//			        				Log.d("temp",""+temp_hold);
//			        				//temp is neg
//			        				//diff is pos
//			        				double over=temp_hold+diff;
//			        				//Convert over to positive value
//			        				if(over<0)
//			        				{
//			        					over=over*-1;
//			        				}
//			        			if(over < cal)
//			        			{
//			        				cal=over;
//			        				k1=i;
//			        				k2=j;
//			        			}
//			        			}
//			        		}
			        		//Lets subtract pffset 0 and offset 1
			        		/***************************************/
			        		//COMMENT OUT
			        		//COMMENT OUT
			        		temp_hold=offset0-offset1;
			        		/***************************************/
			        		Log.d("offset_1_2",""+offset0+" "+offset1);
			        		Log.d("soil","actual is "+diff+" corrections "+temp);
			        		hold="";
			        		//Now i and j hold indexes into the array
			        		//we display cal
			        		Log.d("array",Arrays.toString(diff_time0)+ " "+Arrays.toString(diff_time1));
			        		if(diff<0)
			        		{
			        			diff=diff*-1;
			        		}
			        		if(temp_hold<0)
			        		{
			        			temp_hold=temp_hold*-1;
			        		}
			        		Log.d("temp_val",temp_hold+"");
			        		//temp_hold represents the deviation from the ideal value
			        		//So phone_elapsed is actually phone_elapsed- temp_hold
			        		double rtos_phone_elapsed=phone_elapsed-temp_hold;
			        		Log.d("recalc",rtos_phone_elapsed+" "+n3.toString()+" "+Double.toString(estimateKDynamic(rtos_phone_elapsed,node_count)));
			        		//estimate value from here
			        		if(flag==1)
			        		{
			        			
			        			double custom_scale_k=estimateKDynamic(rtos_phone_elapsed+temp_hold, node_count);
				        		//time on node
				        		BigDecimal a1=new BigDecimal(custom_scale_k*node_count);
				        		//time on phone
				        		BigDecimal a2=new BigDecimal(rtos_phone_elapsed);
				        		BigDecimal a3=new BigDecimal(0);
				        		//phone_time-node_time
				        		a3=a2.subtract(a1);
				        		Log.d("scale",""+custom_scale_k+" "+time+" "+estimateKDynamic(phone_elapsed,node_count));
				        		Log.d("scal_bcorec"," "+estimateKDynamic(phone_elapsed, node_count));
				        		//log to file here
				        		appendLogBeforeCorrection(" "+a3.toString()+" "+a1.toString()+" "+a2.toString()+" "+time+" "+device.getAddress()+" "+custom_scale_k+" "+diff+" "+node_count+" "+phone_elapsed+" "+" "+rtos_phone_elapsed+current_nano+" "+log_viewer+"        "+current_nano);
				        		Log.d("cal_cal"," "+a3.toString()+" "+device.getAddress()+" "+custom_scale_k+" "+diff+" "+node_count+" "+phone_elapsed+" "+" "+rtos_phone_elapsed+current_nano+" "+log_viewer);
				        		Log.d("cal",diff-temp_hold+ " "+diff+ " "+time+" "+device.getAddress()+" "+dynamic_k);
			        			
			        			
			        		}
			        		if(flag==1)
			        		{
			        			
			        			
			        			
			        			
			        			
			        			
			        			
			        		double custom_scale_k=estimateKDynamic(rtos_phone_elapsed, node_count);
			        		//time on node
			        		BigDecimal a1=new BigDecimal(custom_scale_k*node_count);
			        		//time on phone
			        		BigDecimal a2=new BigDecimal(rtos_phone_elapsed);
			        		BigDecimal a3=new BigDecimal(0);
			        		//phone_time-node_time
			        		a3=a2.subtract(a1);
			        		Log.d("scale",""+custom_scale_k+" "+time+" "+estimateKDynamic(phone_elapsed,node_count));
			        		Log.d("scal_bcorec"," "+estimateKDynamic(phone_elapsed, node_count));
			        		//log to file here
			        		appendLog(" "+a3.toString()+" "+a1.toString()+" "+a2.toString()+" "+time+" "+device.getAddress()+" "+custom_scale_k+" "+diff+" "+node_count+" "+phone_elapsed+" "+" "+rtos_phone_elapsed+current_nano+" "+log_viewer+"        "+current_nano);
			        		Log.d("cal_cal_new"," "+a3.toString()+" "+device.getAddress()+" "+custom_scale_k+" "+diff+" "+node_count+" "+phone_elapsed+" "+" "+rtos_phone_elapsed+current_nano+" "+log_viewer);
			        		Log.d("cal",diff-temp_hold+ " "+diff+ " "+time+" "+device.getAddress()+" "+dynamic_k);
			        		}
			        		}
			        	

			        			
			        	
			        if(master==false)
			        {
			        	Log.d("moonight",current_nano+" "+time);
			        }

			        if(master==false)
			        {
			        	Log.d("starsign",String.format("%f", Double.parseDouble(current_nano))+" "+time+" "+transmit_time+" "+min);
			        }

			        	
			runOnUiThread(new Runnable() {
			                
			                public void run() {
			                	String nanoTime;
			                	nanoTime=current_nano;
			                	
			                	{
			                		Log.d("number","inside");
			                		Log.d("number_val",Integer.toString(number));
			                		if(master)
			                		{
			                		//data_node.put(device.getAddress(), new Time_Data(current_nano,Long.toString(node_time_current)));
			                			Log.d("grimm_data",fill.getTime())
			;                			onSendButtonPressed(fill,nanoTime);
			                		}
			                		else
			                		{
			                			//Here we have to get the actual ble count
			                			//So we call caluclate offset
			                			//determineOffset(fill.getTime());
			                			
			                		}
			                		number=0;
			                	}
			                
			                	
			                	
//			                	if(master)
//			                		{
//			                		//data_node.put(device.getAddress(), new Time_Data(current_nano,Long.toString(node_time_current)));
//			                	    onSendButtonPressed(fill,nanoTime);
//			                		}
			                	
			                	
			                	
			                	
			                	
			                	
			                	
			                	
			                	
			                }
			            });
			        
			        	
			        	
			        	
			        	
			        	
			        	
			        	
			        	
			        	
			        	
			        	
			        	
			        	
			        	time=0;
			            
			        
				 }
				 catch(Exception e)
				 {
					 
				 }
			 }
		 };
		 
		 ble_onComplete.start();
	 }
	 
	 
	 public static int unsignedToBytes(byte b) {
		    return b & 0xFF;
		  }
	 
	 
	 
	 
	 
	 
	 
	   private native void helloLog(String logThis);
	    private native String getString(int value1, int value2);
	    
	    static {
	        System.loadLibrary("ndk1");
	    }
	 
	 

	    
	    
	    
	    
	    
	    
	    
	    
	    
}























