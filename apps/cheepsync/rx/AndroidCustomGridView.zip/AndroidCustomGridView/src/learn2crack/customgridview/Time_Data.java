package learn2crack.customgridview;

import android.bluetooth.BluetoothDevice;

public class Time_Data {
	
     String android_nano_time;
     String node_time;
     
     
	public Time_Data(String android_nano_time, String node_time) {
		super();
		this.android_nano_time = android_nano_time;
		this.node_time = node_time;
	}
	public String getAndroid_nano_time() {
		return android_nano_time;
	}
	public void setAndroid_nano_time(String android_nano_time) {
		this.android_nano_time = android_nano_time;
	}
	public String getNode_time() {
		return node_time;
	}
	public void setNode_time(String node_time) {
		this.node_time = node_time;
	}

}
