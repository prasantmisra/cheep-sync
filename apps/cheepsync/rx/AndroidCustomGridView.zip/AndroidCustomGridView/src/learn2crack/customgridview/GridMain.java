package learn2crack.customgridview;



import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import com.google.cloud.backend.R;
import com.markupartist.android.widget.ActionBar;
import com.markupartist.android.widget.ActionBar.Action;
import com.markupartist.android.widget.ActionBar.IntentAction;

public class GridMain extends Activity {
	GridView grid;
	String[] web = {
		    "Google",
			"Github",
			"Instagram",
			"Facebook",
			"Flickr",
			"Pinterest",
			"Quora",
			"Twitter",
			"Vimeo",
			"WordPress",
			"Youtube",
			"Stumbleupon",
			"SoundCloud",
			"Reddit",
			"Blogger"
			
	} ;
	int[] imageId = {
			R.drawable.image1,
			R.drawable.image2,
			R.drawable.image3,
			R.drawable.image4,
			R.drawable.image5,
			R.drawable.image6,
			R.drawable.image7,
			R.drawable.image8,
			R.drawable.image9,
			R.drawable.image10,
			R.drawable.image11,
			R.drawable.image12,
			R.drawable.image13,
			R.drawable.image14,
			R.drawable.image15
			
			
			
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.grid_main);
		 final ActionBar actionBar = (ActionBar) findViewById(R.id.actionbar);
	       // actionBar.setHomeAction(new IntentAction(this, createIntent(this), R.drawable.ic_title_home_demo));
	        //actionBar.setHomeAction(new Intent)
	        //android.app.ActionBar.class
	        //actionBar.setHomeAction(new IntentAction(this,createIntent(this,R.drawable.ic_title_home_demo)))
	        //actionBar.setHomeAction(new IntentAction(this,createIntent(this),R,drawable.ic_title_home_demo));
	        //actionBar.setHomeAction(action)
	        //actionBar.setTitle("Home");
		 //actionBar.settitle
		 //actionBar.settitle("Home");
		 actionBar.setTitle("Home");

	        final Action shareAction = new IntentAction(this, createIntent(this), R.drawable.ic_title_share_default);
	        actionBar.addAction(shareAction);
		    //actionBar.addAction(new ToastAction());
	        //final Action otherAction = new IntentAction(this, new Intent(this, OtherActivity.class), R.drawable.ic_title_export_default);
	        //actionBar.addAction(otherAction);

		
		CustomGrid adapter = new CustomGrid(GridMain.this, web, imageId);
		grid=(GridView)findViewById(R.id.grid);
				grid.setAdapter(adapter);
				grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {

		            @Override
		            public void onItemClick(AdapterView<?> parent, View view,
		                                    int position, long id) {
		                Toast.makeText(GridMain.this, "You Clicked at " +web[+ position], Toast.LENGTH_SHORT).show();
		                //Intent loginintent = new Intent("com.androidhive.googleplacesandmaps.MainActivity");
		                
                        //startActivity(loginintent);
                        //Intent intent -
                        //Intent intent=new Intent(getApplicationContext(),DeviceScanActivity.class);
                        //Intent intent=new()
                        //		Intent intent=new Intent(getApplicationContetx)
                        //Intent intent=new Intent(getApplicationContext(),DeviceControlActi)
                        //Intent intent=new Intent(geAp)
                        //Intent intent=new Intent(getApplicationContext(),DeviceControlActivity.class);
		                //getWindow().addFlags(
                          //      WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
                        //getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                        //Intent intent=new Intent(getApplicationContext(),DeviceScanActivity.class);
                        //startActivity(intent);
                        //startActivity(intent);
                        //Intent intent= new Intent(getApplicat)
                        //Intent intent=new Intent(getApplicationContext(),GuestBookActivity.class);
                        //startActivity(intent);
                        //Intent intent=new intent(get)
                        //intent intent=new Intent(getApplicationContext(),GuestbookActivity.class);
                        //startActivity(intent);
                        //Intent itn
                        //Intent intent=new Intetn
                        //Intent intent =new Intent(getApplicationCOntext(),Guestbooka)
                        //Intent intent=new Intent(getApplicationContext(),GuestbookActivity.class);
                        //in
		                if(position==0)
		                {
		                	Intent intent=new Intent(getApplicationContext(),DeviceScanActivity.class);
	                        startActivity(intent);
		                }
		                else
		                {
                        Intent intent=new Intent(getApplicationContext(),GuestbookActivity.class);
                        startActivity(intent);
		                }

		            }
		        });

	}

	 public static Intent createIntent(Context context) {
		//return null;
//	        Intent i = new Intent(context, HomeActivity.class);
//	        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//	        return i;
        //Intent intent=new Intent();
        //Intent
        Intent intent=new Intent(context,SetPreferenceActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        //intent.setClass(context,SetPreferenceActivity.class);
        //startActivityForResult(intent,0);
        return intent;
	    }

	    private Intent createShareIntent() {
//	        final Intent intent = new Intent(Intent.ACTION_SEND);
//	        intent.setType("text/plain");
//	        intent.putExtra(Intent.EXTRA_TEXT, "Shared from the ActionBar widget.");
//	        return Intent.createChooser(intent, "Share");
	    	

			// TODO Auto-generated method stub
	    	//Intent intent = new Intent();
	        //intent.setClass(MainActivity.this, SetPreferenceActivity.class);
	        //startActivityForResult(intent, 0); 
	        //Intent intent=new Intent();
	        //intent.setClass(GridMain.this,SetPreferenceActivity.class);
	        //startActivityForResult(intent,0);
	        //return intent;
	        
	        return null;


		
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    	
	    }

}
